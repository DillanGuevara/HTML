const drag = document.querySelector(".drag");
const dragText = drag.querySelector('h2');
const button = drag.querySelector('button');
const input = drag.querySelector('#Imagen');
let files;

button.addEventListener('click', (e) => {
    input.click();
});

input.addEventListener('change', (e) => {
    files = input.files;
    drag.classList.add("active");
    showFiles(files);
    drag.classList.remove("active");
});

drag.addEventListener("dragover", (e) => {
    e.preventDefault();
    drag.classList.add("active");
    dragText.textContent = "Suelta para subir los archivos";
});

drag.addEventListener("dragleave", (e) => {
    e.preventDefault();
    drag.classList.remove("active");
    dragText.textContent = "Arrastra y suelta imágenes";
});

drag.addEventListener("drop", (e) => {
    e.preventDefault();
    files = e.dataTransfer.files;
    showFiles(files);
    drag.classList.remove("active");
    dragText.textContent = "Arrastra y suelta imágenes";
});

function showFiles(files) {
    if(files.length === undefined) {
        processFile(files);
    } else {
        for(const file of files) {
            processFile(file);
        }
    }
}

function processFile(file) {
    const docType = file.type;
    const validExtensions = ['image/svg', 'image/jpeg', 'image/jpg', 'image/gif', 'image/png'];

    if(validExtensions.includes(docType)) {
        const fileReader = new FileReader();
        const id = `file-${Math.random().toString(32).substring(7)}`;

        fileReader.addEventListener('load', e => {
            const fileUrl = fileReader.result;
            const image = `
                <div id="${id}" class="file-container">
                    <img src="${fileUrl}" alt="${file.name}">
                    <div class="status">
                        <span>${file.name}</span>
                        <span class="status-text">
                            Loading...
                        </span>
                    </div>
                </div>
            `;

            const html = document.querySelector('#preview').innerHTML;
            document.querySelector('#preview').innerHTML = image + html;
        });

        fileReader.readAsDataURL(file);
        uploadFile(file, id);
    } else {
        alert("El archivo no es válido");
    }
}

async function uploadFile(file, id) {
    const formData = new FormData();
    formData.append("file", file);

    try {
        const response = await fetch("http://localhost:3000/upload", {
            method: "POST",
            body: formData,
        });

        const responseText = await response.text();
        console.log(responseText);

        document.querySelector(
            `#${id} .status-text`
        ).innerHTML = `<span class="success">¡Archivo subido correctamente!</span>`;
    } catch (error) {
        document.querySelector(
            `#${id} .status-text`
        ).innerHTML = `<span class="failure">El archivo no se pudo subir...</span>`;
    }
}